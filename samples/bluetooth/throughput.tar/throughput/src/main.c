/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-BSD-5-Clause-Nordic
 */

#include <kernel.h>
#include <console/console.h>
#include <sys/printk.h>
#include <string.h>
#include <stdlib.h>
#include <zephyr/types.h>

#include <stddef.h>
#include <errno.h>
#include <zephyr.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/crypto.h>
#include <bluetooth/conn.h>
#include <bluetooth/gatt.h>
#include <bluetooth/hci.h>
#include <bluetooth/uuid.h>
#include "gatt_dm.h"
#include "throughput.h"

#define DEVICE_NAME	CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)

static volatile bool test_ready;
static struct bt_conn *default_conn;
static struct bt_conn *default_conn2;
static struct bt_conn *default_conn3;
static struct bt_conn *default_conn4;
static struct bt_gatt_throughput gatt_throughput;
static struct bt_gatt_exchange_params exchange_params;
int cnt = 0;
int old_cnt = 0;
#define sys_le16_to_cpu(val)(val)
static const char img[][81] = {
#include "img.file"
};

static void exchange_func(struct bt_conn *conn, uint8_t att_err,
		struct bt_gatt_exchange_params *params)
{
	struct bt_conn_info info = {0};
	int err;

	printk("1: MTU exchange %s\n", att_err == 0 ? "successful" : "failed");

	err = bt_conn_get_info(conn, &info);
	if (err){
		printk("Failed to get connection info %d\n", err);
		return;
	}

	if (info.role == BT_CONN_ROLE_MASTER){// && default_conn != NULL){// && default_conn2 != NULL) {
		printk("[ejpark]exchange_fund\n");
		test_ready = true;
	}
}

static void discovery_complete(struct bt_gatt_dm *dm,
		void *context)
{
	int err;
	struct bt_gatt_throughput *throughput = context;
	printk("Service discovery completed\n");

	bt_gatt_dm_data_print(dm);
	bt_gatt_throughput_handles_assign(dm, throughput);
	bt_gatt_dm_data_release(dm);


	exchange_params.func = exchange_func;
	err = bt_gatt_exchange_mtu(bt_gatt_dm_conn_get(dm), &exchange_params);//ejpark0407
	if (err) {
		printk("MTU exchange failed (err %d)\n", err);
	} else {
		printk("MTU exchange pending\n");
	}
}

static void discovery_service_not_found(struct bt_conn *conn,
		void *context)
{
	printk("Service not found\n");
}

static void discovery_error(struct bt_conn *conn,
		int err,
		void *context)
{
	printk("Error while discovering GATT database: (%d)\n", err);
}

struct bt_gatt_dm_cb discovery_cb = {
	.completed         = discovery_complete,
	.service_not_found = discovery_service_not_found,
	.error_found       = discovery_error,
};

static void connected(struct bt_conn *conn, uint8_t hci_err)
{
	struct bt_conn_info info = {0};
	int err;
	err = bt_conn_get_info(conn, &info);//ejpark0407
	if (err) {
		printk("Failed to get connection info %d\n", err);
		return;
	}


	char addr[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(bt_conn_get_dst(conn), addr, sizeof(addr));

	if (hci_err) {
		printk("Failed to connect to %s (%u)\n", addr, hci_err);

		//ejpark0407 start
		if(default_conn == conn){
			bt_conn_unref(default_conn);
			default_conn = NULL;
			//k_sleep(K_MSEC(20));start_scan();
		}
		else if(default_conn2 == conn){
			bt_conn_unref(default_conn2);
			default_conn2 = NULL;
//k_sleep(K_(20));
			start_scan();
		}
		else if(default_conn3 == conn){
			bt_conn_unref(default_conn3);
			default_conn3 = NULL;

			start_scan();
		}
		else if(default_conn4 == conn){
			bt_conn_unref(default_conn4);
			default_conn4 = NULL;

			start_scan();
		}
		else printk("[ejpark] error\n");
		return;
	}
	printk("[ejpark] Connected as %s\n",
			info.role == BT_CONN_ROLE_MASTER ? "master" : "slave");
	printk("[ejpark] Conn. interval is %u units\n", info.le.interval);
	/*
	   if (info.role == BT_CONN_ROLE_MASTER) {
	   if(default_conn == conn){
	   err = bt_gatt_dm_start(default_conn,
	   BT_UUID_THROUGHPUT,
	   &discovery_cb,
	   &gatt_throughput);

	   if (err) {
	   printk("Discover failed (err %d)\n", err);
	   }
	   }
	   else if(default_conn2 == conn){
	   err = bt_gatt_dm_start(default_conn2,
	   BT_UUID_THROUGHPUT,
	   &discovery_cb,
	   &gatt_throughput);

	   if (err) {
	   printk("2: Discover failed (err %d)\n", err);
	   }
	   }
	   }*/
	if( default_conn ==NULL || default_conn2==NULL ||
			default_conn3 == NULL || default_conn4 == NULL) 
{		//k_sleep(K_SECONDS(20));
		start_scan();
}
	else test_ready = true;
}
static bool eir_found(struct bt_data *data, void *user_data)
{
	bt_addr_le_t *addr = user_data;
	int i;

	printk("[AD]: %u data_len %u\n", data->type, data->data_len);

	switch (data->type) {
		case BT_DATA_UUID16_SOME:
		case BT_DATA_UUID16_ALL:
			if (data->data_len % sizeof(uint16_t) != 0U) {
				printk("AD malformed\n");
				return true;
			}

			for (i = 0; i < data->data_len; i += sizeof(uint16_t)) {
				struct bt_le_conn_param *param, *param2;
				struct bt_uuid *uuid;
				uint16_t u16;
				int err;

				memcpy(&u16, &data->data[i], sizeof(u16));
				uuid = BT_UUID_DECLARE_16(sys_le16_to_cpu(u16));
				if (bt_uuid_cmp(uuid, BT_UUID_HRS)) {
					printk("WRONG UUID\n");
					continue;
				}

				err = bt_le_scan_stop();
				if (err) {
					printk("Stop LE scan failed (err %d)\n", err);
					continue;
				}

				param = BT_LE_CONN_PARAM_DEFAULT;
				param2 = BT_LE_CONN_PARAM_DEFAULT2; 
				if(default_conn == NULL){
					err = bt_conn_le_create(addr, BT_CONN_LE_CREATE_CONN,
							param, &default_conn);
					if (err) {
						printk("Create conn failed (err %d)\n", err);
					}
				}
				else if(default_conn2 == NULL){
					err = bt_conn_le_create(addr, BT_CONN_LE_CREATE_CONN,
							param, &default_conn2);
					if (err) {
						printk("Create conn failed (err %d)\n", err);
					}
				}
				else if(default_conn3 == NULL){
					err = bt_conn_le_create(addr, BT_CONN_LE_CREATE_CONN,
							param, &default_conn3);
					if (err) {
						printk("Create conn failed (err %d)\n", err);
					}
				}
				else if(default_conn4 == NULL){
					err = bt_conn_le_create(addr, BT_CONN_LE_CREATE_CONN,
							param, &default_conn4);
					if (err) {
						printk("Create conn failed (err %d)\n", err);
					}
				}
				if(default_conn2==NULL || default_conn ==NULL
						|| default_conn3==NULL || default_conn4==NULL) 
				//k_sleep(K_SECONDS(20));
					start_scan();

				
				return false;
			}
	}

	return true;
}

static void device_found(const bt_addr_le_t *addr, uint8_t rssi, uint8_t type,
		struct net_buf_simple *ad)
{
	char dev[BT_ADDR_LE_STR_LEN];

	bt_addr_le_to_str(addr, dev, sizeof(dev));

	/* We're only interested in connectable events */
	if (type == BT_GAP_ADV_TYPE_ADV_IND ||
			type == BT_GAP_ADV_TYPE_ADV_DIRECT_IND) {
		bt_data_parse(ad, eir_found, (void *)addr);
		printk("[DEVICE]: %s, AD evt type %u, AD data len %u, RSSI %i\n",
				dev, type, ad->len, rssi);

	}
}


void start_scan(void)
{
	int err;

	/* Use active scanning and disable duplicate filtering to handle any
	 * devices that might update their advertising data at runtime. */
	struct bt_le_scan_param scan_param = {
		.type       = BT_LE_SCAN_TYPE_ACTIVE,
		.options    = BT_LE_SCAN_OPT_FILTER_DUPLICATE, // BT_LE_SCAN_OPT_NONE,
		.interval   = BT_GAP_SCAN_FAST_INTERVAL,
		.window     = BT_GAP_SCAN_FAST_WINDOW,
	};

	err = bt_le_scan_start(&scan_param, device_found);
	if (err) {
		printk("Scanning failed to start (err %d)\n", err);
		return;
	}

	printk("Scanning successfully started\n");
}
static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	struct bt_conn_info info = {0};
	int err;

	printk("[ejpark] Disconnected (reason 0x%02x)\n", reason);

	if(conn == default_conn){
		printk("[ejpark]disconnected\n");

		test_ready = false;
		bt_conn_unref(conn);
		default_conn = NULL;
	}
	else if(conn == default_conn2){
		printk("[ejpark]disconnected2\n");
		test_ready = false;
		bt_conn_unref(conn);
		default_conn2 = NULL;
	}
	else if(conn == default_conn3){
		printk("[ejpark]disconnected3\n");
		test_ready = false;
		bt_conn_unref(conn);
		default_conn3 = NULL;
	}
	else if(conn == default_conn4){
		printk("[ejpark]disconnected4\n");
		test_ready = false;
		bt_conn_unref(conn);
		default_conn4 = NULL;
	}
	err = bt_conn_get_info(conn, &info);
	if (err) {
		printk("Failed to get connection info (%d)\n", err);
		return;
	}

	/* Re-connect using same roles */
	if (info.role == BT_CONN_ROLE_MASTER) {
//k_sleep(K_SECONDS(20));
		start_scan();
	}
}

static uint8_t throughput_read(const struct bt_gatt_throughput_metrics *met)
{
	printk("[peer] received %u bytes (%u KB)"
			" in %u GATT writes at %u bps\n",
			met->write_len, met->write_len / 1024, met->write_count,
			met->write_rate);
	/*printk("[ejpark]throughput_read\n");
	if(met->write_rate>600000 &&(old_cnt == 0 || cnt-old_cnt>0) ){
		printk("[local]triggered %d\n", cnt);
		old_cnt = cnt; 
		if(cnt%2 ==0)
			bt_conn_le_conn_update_kara(default_conn,BT_LE_CONN_PARAM_DEFAULT, 0x0005);
		else if (cnt%2 == 1) 
			bt_conn_le_conn_update_kara(default_conn2,BT_LE_CONN_PARAM_DEFAULT, 0x0005);
/*		else if (cnt%4 == 2)
			bt_conn_le_conn_update_kara(default_conn3,BT_LE_CONN_PARAM_DEFAULT, 1U);
		else if (cnt%4 == 3)
			bt_conn_le_conn_update_kara(default_conn4,BT_LE_CONN_PARAM_DEFAULT, 1U);
	}*/
	test_ready = true;
	cnt ++;

	return BT_GATT_ITER_STOP;
}
static void throughput_received(const struct bt_gatt_throughput_metrics *met)
{
	static uint32_t kb;

	if (met->write_len == 0) {
		kb = 0;
		printk("\n");

		return;
	}

	if ((met->write_len / 1024) != kb) {
		kb = (met->write_len / 1024);
		printk("=");
	}
}
static void throughput_send(const struct bt_gatt_throughput_metrics *met)
{
	printk("\n[local] received %u bytes (%u KB)"
			" in %u GATT writes at %u bps\n",
			met->write_len, met->write_len / 1024,
			met->write_count, met->write_rate);
}
static const struct bt_gatt_throughput_cb throughput_cb = {
	.data_read = throughput_read,
	.data_received = throughput_received,
	.data_send = throughput_send
};
static void test_run(void)
{
	int err;
	uint64_t stamp;
	uint32_t delta;
	uint32_t data = 0;
	uint32_t prog = 0;

	/* a dummy data buffer */
	static char dummy[256];//ejpark0401

	/* wait for user input to continue */
	//	printk("Ready, press any key to start\n");
	//	console_getchar();//ejpark

	if (!test_ready) {
		/* disconnected while blocking inside _getchar() */
		return;
	}
	test_ready = false;
	printk("[ejpark]test_run\n");


	/* reset peer metrics */
	err = bt_gatt_throughput_write(&gatt_throughput, dummy, 1);
	if (err) {
		printk("Reset peer metrics failed.\n");
		return;
	}


	/* get cycle stamp */
	stamp = k_uptime_get_32();

	while (prog < IMG_SIZE) {
		err = bt_gatt_throughput_write(&gatt_throughput, dummy, 244);//ejpark0401
		if (err) {
			printk("GATT write failed (err %d)\n", err);
			break;
		}

		/* print graphics */
		//printk("%c", img[prog / IMG_X][prog % IMG_X]);
		data += 244;
		prog++;
		k_sleep(K_MSEC(15));
	}

	delta = k_uptime_delta_32(&stamp);

	printk("\nDone\n");
	printk("[local] slave %d: sent %u bytes (%u KB) in %u ms at %llu kbps\n",cnt%4,
			data, data / 1024, delta, ((uint64_t)data * 8 / delta));

	/* read back char from peer */
	err = bt_gatt_throughput_read(&gatt_throughput);
	if (err) {
		printk("GATT read failed (err %d)\n", err);
	}

}

static bool le_param_req(struct bt_conn *conn, struct bt_le_conn_param *param)
{
	/* reject peer conn param request */
	return false;
	//return true;
}

void main(void)
{
	int err;

	static struct bt_conn_cb conn_callbacks = {
		.connected = connected,
		.disconnected = disconnected,
		.le_param_req = le_param_req,
	};

	printk("Starting Bluetooth Throughput example\n");

	//:console_init();

	bt_conn_cb_register(&conn_callbacks);

	err = bt_enable(NULL);
	if (err) {
		printk("Bluetooth init failed (err %d)\n", err);
		return;
	}

	default_conn = NULL;
	default_conn2 = NULL;
	default_conn3 = NULL;
	default_conn4 = NULL;

	printk("Bluetooth initialized\n");

	start_scan();

	err = bt_gatt_throughput_init(&gatt_throughput, &throughput_cb);
	if (err) {
		printk("Throughput service initialization failed.\n");
		return;
	}
	//err = bt_gatt_throughput_init(&gatt_throughput2, &throughput_cb2);
	//if (err) {
	//	printk("Throughput service initialization failed.\n");
	//	return;
	//}
	k_sleep(K_SECONDS(5));

	for ( ;;) {
		if (test_ready) {
			//if(cnt == 0 ) k_sleep(K_SECONDS(5));
			if(cnt%4 == 0){
				err = bt_gatt_dm_start(default_conn,
						BT_UUID_THROUGHPUT,
						&discovery_cb,
						&gatt_throughput);
				if (err) {
					printk("Discover failed (err %d)\n", err);
				}
				test_ready = false;
				printk("[ejpark]Start %d\n",cnt);
				while(!test_ready);
				test_run();
			}

			else if(cnt%4 == 1){
				err = bt_gatt_dm_start(default_conn2,
						BT_UUID_THROUGHPUT,
						&discovery_cb,
						&gatt_throughput);
				if (err) {
					printk("Discover failed (err %d)\n", err);
				}
				test_ready = false;
				printk("[ejpark]Start %d\n",cnt);
				while(!test_ready);
				test_run();

			}
			else if(cnt%4 == 2){
				err = bt_gatt_dm_start(default_conn3,
						BT_UUID_THROUGHPUT,
						&discovery_cb,
						&gatt_throughput);
				if (err) {
					printk("Discover failed (err %d)\n", err);
				}
				test_ready = false;
				printk("[ejpark]Start %d\n",cnt);
				while(!test_ready);
				test_run();

			}
			else if(cnt%4 == 3){
				err = bt_gatt_dm_start(default_conn4,
						BT_UUID_THROUGHPUT,
						&discovery_cb,
						&gatt_throughput);
				if (err) {
					printk("Discover failed (err %d)\n", err);
				}
				test_ready = false;
				printk("[ejpark]Start %d\n",cnt);
				 
				while(!test_ready);
				test_run();

			}
		}
	}

}

